
import React from 'react';
import { BrandingPreviewProps } from '../types';

export const BrandingPreview: React.FC<BrandingPreviewProps> = ({ logoUrl }) => {
  return (
    <div className="space-y-6">
      <h3 className="text-xl font-display font-bold flex items-center gap-2">
        <span className="material-symbols-outlined text-primary">mail</span>
        Branding Preview
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Email Header Mockup */}
        <div className="glass p-4 rounded-xl border-white/10 overflow-hidden">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Email Template</p>
          <div className="bg-slate-900 rounded-lg p-6 border border-white/5 shadow-2xl">
            <div className="flex justify-center mb-6">
              <img src={logoUrl} alt="Logo" className="h-12 w-auto object-contain rounded" />
            </div>
            <div className="h-2 w-1/3 bg-slate-800 rounded mb-3"></div>
            <div className="space-y-2">
              <div className="h-2 w-full bg-slate-800 rounded opacity-50"></div>
              <div className="h-2 w-full bg-slate-800 rounded opacity-50"></div>
              <div className="h-2 w-3/4 bg-slate-800 rounded opacity-50"></div>
            </div>
            <div className="mt-8 pt-4 border-t border-slate-800 flex justify-center">
              <div className="h-2 w-20 bg-primary/20 rounded"></div>
            </div>
          </div>
        </div>

        {/* Website Header Mockup */}
        <div className="glass p-4 rounded-xl border-white/10 overflow-hidden">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Website Header</p>
          <div className="bg-[#0B0B1E] rounded-lg border border-white/5 h-40 relative">
             <header className="flex items-center justify-between px-4 py-2 border-b border-white/10">
                <div className="flex items-center gap-2">
                   <img src={logoUrl} alt="Logo" className="h-6 w-6 rounded" />
                   <span className="text-[10px] font-extrabold uppercase tracking-tight text-white">Mytherion</span>
                </div>
                <div className="flex gap-2">
                  <div className="h-2 w-6 bg-white/5 rounded"></div>
                  <div className="h-2 w-6 bg-white/5 rounded"></div>
                </div>
             </header>
             <div className="p-4">
               <div className="h-10 w-32 bg-primary/20 rounded-lg border border-primary/30 flex items-center justify-center">
                 <div className="h-2 w-16 bg-white/20 rounded"></div>
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};
