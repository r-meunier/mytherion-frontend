
export enum LogoStyle {
  MINIMAL_ICON = 'Minimalist Icon',
  TYPOGRAPHIC = 'Typographic',
  EMBLEM = 'Emblem/Heraldic',
  NEON_ARCANE = 'Neon Arcane',
}

export interface GeneratedLogo {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
  style: LogoStyle;
}

export interface BrandingPreviewProps {
  logoUrl: string;
}
