
import React, { useState, useCallback } from 'react';
import { LogoStyle, GeneratedLogo } from './types';
import { generateLogoImage } from './services/geminiService';
import { BrandingPreview } from './components/BrandingPreview';

const App: React.FC = () => {
  const [activeStyle, setActiveStyle] = useState<LogoStyle>(LogoStyle.MINIMAL_ICON);
  const [customPrompt, setCustomPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [logos, setLogos] = useState<GeneratedLogo[]>([]);
  const [selectedLogoId, setSelectedLogoId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const imageUrl = await generateLogoImage(activeStyle, customPrompt);
      const newLogo: GeneratedLogo = {
        id: Math.random().toString(36).substring(7),
        url: imageUrl,
        prompt: customPrompt || `A ${activeStyle} logo for Mytherion`,
        timestamp: Date.now(),
        style: activeStyle,
      };
      setLogos(prev => [newLogo, ...prev]);
      setSelectedLogoId(newLogo.id);
    } catch (err) {
      setError('Failed to generate logo. Please check your connection or try a different style.');
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const selectedLogo = logos.find(l => l.id === selectedLogoId);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 lg:px-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-6">
        <div>
          <h1 className="text-4xl lg:text-5xl font-display font-extrabold text-white flex items-center gap-4">
            <span className="bg-gradient-to-tr from-primary to-purple-400 p-2 rounded-xl shadow-lg shadow-primary/30">
              <span className="material-symbols-outlined text-white text-3xl">auto_awesome</span>
            </span>
            MYTHERION <span className="text-primary/70 font-light">LOGO LAB</span>
          </h1>
          <p className="text-slate-400 mt-2 text-lg">Forge the visual identity of your legendary worlds.</p>
        </div>
        <div className="flex items-center gap-4 bg-white/5 p-2 rounded-2xl border border-white/10">
          <div className="text-right">
            <p className="text-sm font-bold text-white uppercase tracking-wider">Alistair Thorne</p>
            <p className="text-[10px] text-primary font-bold uppercase">Master Chronicler</p>
          </div>
          <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary/30">
            <img src="https://picsum.photos/seed/alistair/100/100" alt="Avatar" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Controls */}
        <div className="lg:col-span-4 space-y-8">
          <section className="glass p-6 rounded-3xl border-white/10">
            <h2 className="text-xl font-display font-bold mb-6 flex items-center gap-2">
              <span className="material-symbols-outlined text-secondary">brush</span>
              Design Parameters
            </h2>

            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Choose Base Style</label>
                <div className="grid grid-cols-1 gap-2">
                  {Object.values(LogoStyle).map((style) => (
                    <button
                      key={style}
                      onClick={() => setActiveStyle(style)}
                      className={`flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${
                        activeStyle === style 
                        ? 'bg-primary/20 border-primary text-white shadow-lg shadow-primary/10' 
                        : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
                      }`}
                    >
                      <span className="font-medium">{style}</span>
                      {activeStyle === style && <span className="material-symbols-outlined text-sm">check_circle</span>}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Custom Refinements</label>
                <textarea
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  placeholder="e.g. add a golden dragon tail to the M, or use more neon indigo..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary focus:border-transparent outline-none transition-all h-24 text-slate-200 resize-none"
                />
              </div>

              <button
                onClick={handleGenerate}
                disabled={isGenerating}
                className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-all shadow-xl ${
                  isGenerating 
                  ? 'bg-primary/50 cursor-not-allowed opacity-70' 
                  : 'bg-primary hover:bg-primary/80 text-white shadow-primary/20 hover:-translate-y-0.5'
                }`}
              >
                {isGenerating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Forging Logo...
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined">auto_fix_high</span>
                    Generate Brand Identity
                  </>
                )}
              </button>

              {error && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-xs flex items-center gap-2">
                  <span className="material-symbols-outlined text-sm">error</span>
                  {error}
                </div>
              )}
            </div>
          </section>

          {/* History / Gallery */}
          <section className="glass p-6 rounded-3xl border-white/10">
            <h2 className="text-xl font-display font-bold mb-6 flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">history</span>
              Chronicle of Designs
            </h2>
            <div className="grid grid-cols-3 gap-3">
              {logos.length > 0 ? (
                logos.map((logo) => (
                  <button
                    key={logo.id}
                    onClick={() => setSelectedLogoId(logo.id)}
                    className={`aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                      selectedLogoId === logo.id ? 'border-primary ring-2 ring-primary/20' : 'border-white/5 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={logo.url} alt="Logo thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))
              ) : (
                <div className="col-span-3 py-12 text-center text-slate-500">
                  <span className="material-symbols-outlined text-4xl mb-2 opacity-20">landscape</span>
                  <p className="text-xs font-medium">No logos forged yet.</p>
                </div>
              )}
            </div>
          </section>
        </div>

        {/* Preview Area */}
        <div className="lg:col-span-8 space-y-8">
          <div className="glass p-8 rounded-[2rem] border-white/10 min-h-[600px] flex flex-col">
            {selectedLogo ? (
              <div className="flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl font-display font-extrabold text-white">Active Design</h2>
                    <p className="text-sm text-slate-400 mt-1 uppercase tracking-widest font-bold">
                      {selectedLogo.style} • Generated {new Date(selectedLogo.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = selectedLogo.url;
                        link.download = `Mytherion-Logo-${selectedLogo.id}.png`;
                        link.click();
                      }}
                      className="p-3 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all text-slate-200" title="Download PNG">
                      <span className="material-symbols-outlined">download</span>
                    </button>
                    <button className="p-3 bg-white/5 rounded-xl border border-white/10 hover:bg-white/10 transition-all text-slate-200" title="Share">
                      <span className="material-symbols-outlined">share</span>
                    </button>
                  </div>
                </div>

                <div className="flex-1 flex flex-col lg:flex-row gap-12 items-start">
                  <div className="w-full lg:w-1/2 aspect-square rounded-[2rem] overflow-hidden bg-[#0B0B1E] shadow-2xl border border-white/10 group relative">
                    <img src={selectedLogo.url} alt="Generated Logo" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                       <span className="text-white text-sm font-bold bg-black/50 px-4 py-2 rounded-full backdrop-blur-md border border-white/20">
                         Click to enlarge
                       </span>
                    </div>
                  </div>

                  <div className="w-full lg:w-1/2 space-y-10">
                    <BrandingPreview logoUrl={selectedLogo.url} />
                    
                    <div className="p-5 bg-primary/5 rounded-2xl border border-primary/20">
                      <p className="text-xs font-bold text-primary uppercase tracking-widest mb-2">Lore Note</p>
                      <p className="text-sm text-slate-300 italic leading-relaxed">
                        "A symbol represents more than just a name; it is the crest under which your legends are told. This design captures the essence of Mytherion's arcane heritage."
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 py-20">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                   <span className="material-symbols-outlined text-5xl text-primary animate-pulse">auto_fix_normal</span>
                </div>
                <h2 className="text-3xl font-display font-bold text-white">Start Forging Your Brand</h2>
                <p className="text-slate-400 max-w-md mx-auto">
                  Select a style on the left and click 'Generate' to see your new Mytherion logo across email templates and web headers.
                </p>
              </div>
            )}
          </div>

          {/* Prompt Guide Footer */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="glass p-6 rounded-3xl border-white/10 bg-gradient-to-br from-purple-900/10 to-transparent">
                <h4 className="text-white font-bold mb-3 flex items-center gap-2 uppercase text-xs tracking-widest">
                  <span className="material-symbols-outlined text-secondary text-lg">lightbulb</span>
                  Design Tip: Color Harmony
                </h4>
                <p className="text-sm text-slate-400 leading-relaxed">
                  For Mytherion branding, always prioritize <span className="text-primary font-bold">Royal Purple (#A855F7)</span> for energy and <span className="text-secondary font-bold">Amber Gold (#FBBF24)</span> for ancient wisdom.
                </p>
             </div>
             <div className="glass p-6 rounded-3xl border-white/10 bg-gradient-to-br from-blue-900/10 to-transparent">
                <h4 className="text-white font-bold mb-3 flex items-center gap-2 uppercase text-xs tracking-widest">
                  <span className="material-symbols-outlined text-primary text-lg">explore</span>
                  Utility Across Templates
                </h4>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Minimalist icons work best for favicon and mobile apps, while Emblems add gravity to formal PDF character sheets and email signatures.
                </p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
