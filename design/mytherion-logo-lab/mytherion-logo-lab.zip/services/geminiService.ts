
import { GoogleGenAI } from "@google/genai";
import { LogoStyle } from "../types";

export const generateLogoImage = async (style: LogoStyle, customRequest: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const stylePrompts = {
    [LogoStyle.MINIMAL_ICON]: "A premium minimalist vector logo. A stylized, geometric letter 'M' designed to look like a mystical portal or an open ancient book. Clean lines, symmetrical. Colors: Royal purple and glowing gold. Solid dark background.",
    [LogoStyle.TYPOGRAPHIC]: "Elegant typographic logo with the word 'MYTHERION'. Luxurious serif font with mystical fantasy flourishes. The letter 'M' has a small star or spark icon integrated. Metallic gold texture on deep purple background.",
    [LogoStyle.EMBLEM]: "A heraldic shield emblem logo for 'Mytherion'. A central celestial symbol with an 'M' inscribed. Surrounded by delicate star constellations and arcane orbits. Gold and violet color palette. Professional flat design.",
    [LogoStyle.NEON_ARCANE]: "Futuristic arcane logo with glowing neon 'M' symbol. Synthwave fantasy aesthetic. Sharp glowing edges, ethereal particles. Deep indigo background with purple and gold energy surges.",
  };

  const basePrompt = stylePrompts[style];
  const fullPrompt = `Logo design for Mytherion. ${basePrompt} ${customRequest ? `Additionally: ${customRequest}` : ''}. High resolution, professional branding, isolated on dark background, centered composition.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: fullPrompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    
    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Gemini Image Gen Error:", error);
    throw error;
  }
};
